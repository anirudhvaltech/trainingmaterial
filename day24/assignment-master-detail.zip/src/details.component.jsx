import { useParams } from "react-router-dom"
import data from "./heroesdata.json"
function DetailsComp(){
    let params = useParams()
    let hid = params.hid;
    // console.log(heroData);
    return <div>
        <h1>Details</h1>
        {data.heroes.map((val)=>{
            if(hid===val.id){
                return <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Intelligence</th>
                    <th scope="col">Speed</th>
                    <th scope="col">Strength</th>
                  </tr>
                </thead>
                <tbody>
                  
                   <tr key={val.id}>
                    <td>{val.id+1}</td>
                    <td>{val.name}</td>
                    <td>{val.powerstats.intelligence}</td>
                    <td>{val.powerstats.strength}</td>
                    <td>{val.powerstats.speed}</td>
                    </tr>
                    
                  
                </tbody>
              </table>
                    
                
            }
        })}
    
    </div>
}

export default DetailsComp
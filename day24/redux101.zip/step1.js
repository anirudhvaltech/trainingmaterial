let redux = require("redux")
let createStore = redux.legacy_createStore;

//action type
//action creator is function that returns an action object
//initial state is initial value of store object
//reducer is a function which has switch cases to call functions based on action type
//store is an object that stores all shared states of your application
//subscribe/unsubscribe to listen to changes of the store
//dispatch is a method that can take action object

//ACTION
const ADDHERO = "ADDHERO";

//ACTION creator
let addhero = function(){
    return {
        type: ADDHERO
    }
};

//INITIAL STATE
let initialState = {
    numberOfHeroes : 0
}

//REDUCER
let reducer = (state = initialState, action)=>{
    switch(action.type){
        case ADDHERO: return { numberOfHeroes : state.numberOfHeroes+1 };
        default: return state     
    }
};

let store = createStore(reducer);
console.log("initial value of store", store.getState())

let unsubscribe = store.subscribe(()=>{
    console.log("Subscribed", store.getState())
})

store.dispatch( addhero() );
store.dispatch( addhero() );
store.dispatch( addhero() );
store.dispatch( addhero() );
store.dispatch( addhero() );
unsubscribe();
console.log("unsubscribed");//no longer calls the function but states will still be updated
store.dispatch( addhero() );
store.dispatch( addhero() );

console.log(store.getState())
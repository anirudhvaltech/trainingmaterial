function BatmanMovie3Comp(){
    return (
        <div>
            <h1>Batman Movie 3 Component</h1>

        </div>
    )
}

export default BatmanMovie3Comp;
function BatmanMovie1Comp(){
    return (
        <div>
            <h1>Batman Movie 1 Component</h1>

        </div>
    )
}

export default BatmanMovie1Comp;
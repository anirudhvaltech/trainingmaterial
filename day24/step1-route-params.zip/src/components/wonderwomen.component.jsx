import { useParams } from 'react-router-dom'

function WonderWomenComp(){
    let params = useParams();
    return (
        <div>
            <h1>WonderWomen Component</h1>
            <h2>Quantity: {Number(params.qty)+10 || 0}</h2>
        </div>
    )
}

export default WonderWomenComp;
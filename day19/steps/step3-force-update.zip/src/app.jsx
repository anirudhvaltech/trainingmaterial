import { Component } from "react";
import Hero from "./hero";

class App extends Component{
    avengers = ['Ironman', 'Thor', 'Hulk', 'Scarlet', 'Black Widow','Vision']
    justiceLeague = ['Batman', 'Superman', 'Flash', 'Green Arrow', 'Aquaman','Cyborg', 'Wonder Women']
    indicHeroes = ['Shaktiman', 'Krish','RaOne','Robo']
    render(){
        return <div>
                    <Hero list={this.avengers} version={1} title="Avengers"></Hero>
                    <Hero list={this.justiceLeague} version={2} title="Justice League"></Hero>
                    <Hero list={this.indicHeroes} version={3} title="Indic Heroes"></Hero>
                    <Hero list={this.indicHeroes} version={3} title="Indic Heroes"></Hero>
                </div>
    }
}

export default App;
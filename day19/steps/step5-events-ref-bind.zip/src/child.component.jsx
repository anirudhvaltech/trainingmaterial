import { Component, createRef } from "react";

class ChildComp extends Component{
   state = {
    title : "Default Title",
    power : 0
   }
   elm = createRef();
   /*    
   constructor(){
    super();
    this.increasePower = this.increasePower.bind(this)
   } 
   */
   increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        });
   }
   setPower = (evt)=>{
        this.setState({
            power : Number(evt.target.value)
        });
   };

   changePower = () => {
    this.setState({
        power : Number( this.elm.current.value )
    })
   };

    render(){
        return <div>
                    <h2>Child Component</h2>
                    <h3>Title : { this.state.title }</h3>
                    <h3>Power : { this.state.power }</h3>
                    {/* <button onClick={ this.increasePower.bind(this) }>Increase Power</button> */}
                    {/* <button onClick={ ()=> this.increasePower }>Increase Power</button> */}
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <br />
                    <input onInput={ (event)=> this.setPower(event) } type="range" />
                    <br />
                    <button onClick={()=>{
                        this.setState({
                            title : "Changed"
                        });
                    }}>Change Title</button>
                    <br />
                    <input ref={this.elm} type="number" />
                    <button onClick={ this.changePower }>Change Power</button>
                </div>
    }
}

export default ChildComp;
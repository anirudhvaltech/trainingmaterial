import { Component } from "react";

class ChildComp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState(function(currentState, currentProp){
            return {
                power : currentState.power + 1
            }
        }, function(){
            console.log(this.state.power);
        });
    }
    render(){
        return <div>
                    <h1>Child Component | Power is { this.state.power }</h1>
                    <button onClick={this.increasePower}>Increase Power</button>
                </div>
    }
}

export default ChildComp;
import axios from "axios"
import { useState } from "react";
import { useEffect } from "react"; 
import "./style.css"

let Product1Comp=()=>{

    let [products,setProducts] = useState([]);
    let [qty,getQty] = useState({qty:0});
    let [nproduct,setCart]=useState({_id:'',hero:'',name:'',price:'',instock:true})

    let refresh=()=>{
        axios.get("http://localhost:2050/data").then(res=>{
            setProducts(res.data)
        })
    }
    useEffect(function(){
        refresh();
    },[]);

    let addCart=(pid)=>{
        axios.get("http://localhost:2050/edit/"+pid).then(res => {
            setCart(res.data);
            
        })
    }

    let clickHandler=(evt)=>{
        getQty({...qty, qty : evt.target.value})
    }
    return<div className="main" style={{display:"flex",justifyContent:"center"}}>
         <div className="maincls">   
                {
                    products.map((product,idx)=>{
                        return <div className="box">
                                        
                                            <div className="card shadow-sm">
                                                <div className="card-body bg"> 
                                                    Title : {product.hero}
                                                    <br/>
                                                    Price : {product.price}
                                                    <br />
                                                    Quantity <br/>
                                                    <br/>
                                                    <input onInput={(evt)=> clickHandler(evt)} type="number" />
                                                    &nbsp;
                                                    <button  onClick={()=>addCart(product._id)}>ADD TO CART</button>
                                                </div>
                                            </div>
                                       
                                    </div>
                            
                    })
                }
                </div>

     <div className="lower" style={{backgroundColor:"brown",justifyContent:"center",width:"400px",height:"700px", color:"white", padding: "10px"}}>
        <h1>Bill Amount </h1><br /><br />
        <p>Name: {nproduct.hero}</p>
        <p>Price: {nproduct.price}</p>
        <p>Qty: {qty.qty}</p>
        <p>Total Amount: {nproduct.price*qty.qty}</p>
     </div>

    </div>      
}

export default Product1Comp;
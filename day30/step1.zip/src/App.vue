<template>
  <div>
    <h1>{{ title }}</h1>
    <h1>{{ title.toUpperCase() }}</h1>
    <h2>{{ age }}</h2>
    <hr>
    <h1 v-text="title"></h1>
    <div v-html="messagetag"></div>
    <div :class="dynamicClass">Hello There</div>
    <div :id="dynamicID">Hello There</div>
    <button :disabled="show">Click Me</button>
    <input type="checkBox" v-model="show">
    <input type="text" v-model="title">
    <fieldset :hidden="!show">
      <legend>
        Terms and Conditions
      </legend>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Obcaecati deleniti dignissimos pariatur voluptates quaerat, reprehenderit nemo assumenda. Quia blanditiis, ex adipisci, beatae expedita quisquam dolorem reiciendis delectus, debitis veritatis cum.</p>
    </fieldset>

    <hr>
    <div :class="['box', 'brdr']">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Asperiores perferendis tenetur ut aliquam quia unde voluptate, pariatur animi dolorem sed distinctio, architecto quod repellendus quis veritatis porro totam placeat sunt!
    </div>
    <div :class="{'pinkbox':gender==='female'}">
      Gender Based Style
    </div>

    <button :data-sku="itemid">Item for sale</button>
    <article :lang="speak">
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores magni commodi, vero perspiciatis quidem repellendus molestias sequi saepe, corrupti ullam voluptatibus, rerum ut? Repellendus ipsam fuga dicta esse in pariatur?
    </article>
  </div> 
</template>

<script>
export default {
  name: "App",
  components: {
  },
  data(){
    return {
      title: "Welcome to Valtech_",
      age: 20,
      messagetag: "<span>Welcome to <u>your</u> life</span>",
      show: false,
      dynamicClass: "box",
      dynamicID: "player",
      gender: 'female',
      itemid: 100103
    }
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
#player{
  width: 300px;
  height: 150px;
  background-color: orange;
  color: black;
  text-align: center;
  line-height: 150px;
}
.brdr{
  border: 5px solid purple;
}
.box{
  width: 300px;
  height: 150px;
  background-color: crimson;
  color: cornsilk;
  text-align: center;
  line-height: 150px;
  overflow: auto;
}
.pinkbox{
  height: 100px;
  width: 100px;
  background-color: pink;
}
div:lang('fr'){
  background-color: goldenrod; 
}
</style>

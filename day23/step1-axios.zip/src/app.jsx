
import Heros from "./user.component";
 
let App = ()=> {
    return <div className="container">
                <h1>Ajax Call</h1>
                <Heros/>
            </div>
}

export default App;


 

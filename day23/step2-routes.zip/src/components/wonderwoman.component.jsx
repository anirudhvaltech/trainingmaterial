function WonderWomanComp(){
    return (
        <div>
            <h1>WonderWoman Component</h1>
        </div>
    )
}

export default WonderWomanComp;
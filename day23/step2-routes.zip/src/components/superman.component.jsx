function SupermanComp(){
    return (
        <div>
            <h1>Superman Component</h1>
        </div>
    )
}

export default SupermanComp;
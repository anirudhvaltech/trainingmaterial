function BatmanComp(){
    return (
        <div>
            <h1>Batman Component</h1>
        </div>
    )
}

export default BatmanComp;
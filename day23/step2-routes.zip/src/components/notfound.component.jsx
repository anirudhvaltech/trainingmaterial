function NotFoundComp(){
    return (
        <div>
            <h1>NotFound Component</h1>
        </div>
    )
}

export default NotFoundComp;
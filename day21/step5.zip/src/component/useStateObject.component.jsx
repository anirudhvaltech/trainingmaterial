import { useState } from "react";

let UseStateObjComp=()=>{
    // console.log( useState(0) )
    let [hero, setHero]= useState({firstname:"", lastname: ""});
    // let addHero = () =>{
    //     setHero({
    //         firstname: "Tony",
    //         lastname: "Stark"
    //     })
    // }
    // let addHeroFirstName=function(evt){

    //     setHero({
    
    //         ...hero,
    
    //         firstname:evt.target.value
    
    //     })
    
    //    }
    
    //    let addHeroLastName=function(evt){
    
    //     setHero({
    
    //         ...hero,
    
    //         lastname:evt.target.value
    
    //     })
    
    //    }
    let addHeroName = function(evt){
        setHero({
            ...hero,
            [evt.target.title] : evt.target.value
        })
    }


    return <div>
        <h1>User State Object Hook Component</h1>
        <h2>First Name : { hero.firstname }</h2>
        <h2>Last Name : { hero.lastname }</h2>
        {/* <button onClick={ increasePower }>Increase Power</button> */}
        <label htmlFor="fname">First name: <input title="firstname" onChange={(evt)=>{addHeroName(evt)}} type="text" /></label>
        <label htmlFor="lname">Last name: <input title="lastname" onChange={(evt)=>{addHeroName(evt)}} type="text" /></label>
    </div>
}

export default UseStateObjComp
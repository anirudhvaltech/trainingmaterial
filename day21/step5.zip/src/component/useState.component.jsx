import { useState } from "react";

let UseStateComp=()=>{
    // console.log( useState(0) )
    let [power, setPower]= useState(0);
    let increasePower = () =>{
        setPower(power+1)
    }

    return <div>
        <h1>User State Hook Component</h1>
        <h2>Power : { power }</h2>
        <button onClick={ increasePower }>Increase Power</button>
    </div>
}

export default UseStateComp
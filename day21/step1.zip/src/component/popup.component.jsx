import ReactDOM from "react-dom";
import { Component } from "react";

class PopUp extends Component{
    render(){
        return ReactDOM.createPortal(<div>{this.props.children}</div>, document.getElementById("popup"))
    }
}

export default PopUp
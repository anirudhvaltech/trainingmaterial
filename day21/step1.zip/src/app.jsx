import { Component } from "react";
import PopUp from "./component/popup.component";
 
class App extends Component{
    state={
        title: "Welcome to your life",
        showpopup: false
    }
    togglePopUp = () =>{
        this.setState({
            showpopup: !this.state.showpopup
        })
    }
    changeTitle=()=>{
        this.setState({
            title: "changed from popup"
        })
    }

    render(){
        return <div>
            <h1>{this.state.title}</h1>
            { this.state.showpopup ? <PopUp>
            <h2>{ this.state.title }</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae, enim temporibus ex labore laboriosam sint ab eaque vitae odit? Voluptas adipisci iure quibusdam iste id quasi voluptate pariatur hic minima!
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Soluta est corrupti saepe assumenda numquam asperiores nulla modi? Molestiae temporibus cupiditate perferendis! Delectus optio maiores perspiciatis at similique atque, doloribus assumenda?
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestiae cumque repellat odio, culpa eos ullam recusandae error consequatur rerum. Quae reiciendis molestiae a repudiandae commodi eligendi optio nemo quasi accusantium!
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum debitis sapiente architecto. Nostrum molestias nobis aspernatur cupiditate deserunt, recusandae dolorum explicabo! Voluptatem, voluptatum quam. Ea quo magnam nobis repudiandae ut.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores rem, blanditiis veniam quaerat id recusandae quam? Consequatur labore quasi ea molestiae autem voluptas! Exercitationem placeat ratione, deserunt ut aut quos.
            </p>
            <button onClick={ this.togglePopUp }>Hide Pop-Up Window</button>
            <button onClick={ this.changeTitle }>Change Title</button>
            </PopUp>:<button onClick={this.togglePopUp}>Show Pop-Up Window</button>
            }</div>
    }
}
 
export default App;
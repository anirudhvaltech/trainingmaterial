import { Component } from "react";
import axios from "axios"

class GridComponent extends Component{
    state ={
        users : []
    }
    loadData=()=>{
        axios.get("https://reqres.in/api/users?page=1").then(res=>{
            this.setState({
                users : res.data.data
            })
        })
    }
    componentDidMount(){
        this.loadData();
    }
    render(){
        return <table class="table">
        <thead>
          <tr>
            <th scope="col">Sl</th>
            <th scope="col">Photo</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
          </tr>
        </thead>
        <tbody>
          {
            this.state.users.map((val,idx)=>{
                return  <tr key={val.id}>
                        <td>{idx+1}</td>
                        <td><img width={50} src={val.avatar} alt={val.first_name} /></td>
                        <td>{val.first_name}</td>
                        <td>{val.last_name}</td>
                        </tr>
            })
          }
        </tbody>
      </table>
    }
}

export default GridComponent
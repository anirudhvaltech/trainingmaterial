import { Component } from "react";
import GridComponent from "./grid.component";
 
class App extends Component{
    state = {
        apptitle : "User's Data",
        
    }
    render(){
        return <div className="container">
                <h1>{ this.state.apptitle }</h1>
                <hr />
                <GridComponent/>

               </div>
    }
}
 
export default App;
 
 

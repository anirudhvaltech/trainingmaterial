const { configureStore } = require("@reduxjs/toolkit");
const heroReducer = require("../features/hero/heroSlice")
const movieReducer = require("../features/movie/movieSlice")
let store = configureStore({

    reducer : {
        hero: heroReducer,
        movie: movieReducer
    }
});

module.exports = store;

const { configureStore } = require("@reduxjs/toolkit");
const heroReducer = require("../features/hero/heroSlice")
let store = configureStore({

    reducer : {
        hero: heroReducer
    }
});

module.exports = store;

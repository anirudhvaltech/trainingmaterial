import { ADD_HERO, REMOVE_HERO } from "./hero.types";

const initial_state = {
    numOfHeroes : 0
}

const heroReducer = (state=initial_state, action)=>{
    switch(action.type){
        case ADD_HERO: return {
            ...state, numOfHeroes: state.numOfHeroes+1
        }
        case REMOVE_HERO: return {
            ...state, numOfHeroes: state.numOfHeroes-1
        }
        default: return state;
    }
}

export {heroReducer};
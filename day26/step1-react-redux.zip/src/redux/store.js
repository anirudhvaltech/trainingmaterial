//action type
//action creator
//initial state
//reducer
//store
//subscribe/unsubscribe
//dispatch

import { heroReducer } from "./hero/hero.reducers";
import { legacy_createStore as createStore, combineReducers } from "redux";
import { movieReducer } from "./movie/movie.reducers";

let rootReducer = combineReducers({
    heroes: heroReducer,
    movies: movieReducer
})

let store = createStore(rootReducer);


export default store;
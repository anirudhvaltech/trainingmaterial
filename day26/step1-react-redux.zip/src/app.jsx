import { Component  } from "react";
import HeroComponent from "./components/hero.component";
import HeroHookComp from "./components/hero.hook.comp";
import MovieComponent from "./components/movie.component";
import MovieHookComp from "./components/movie.hook.comp";

class App extends Component{
    render(){
        return <div>
            <h1>Welcome to your life</h1>
            <HeroComponent/>
            <HeroHookComp/>
            <hr />
            <MovieComponent/>
            <MovieHookComp/>
        </div>
    }
}

export default App;
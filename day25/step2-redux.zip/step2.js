let redux = require("redux");
let createStore = redux.legacy_createStore;

//action type
const ADDHERO="ADDHERO";
const REMOVEHERO="REMOVEHERO";
const SETHERO="SETHERO";

//action creator is function that returns an action object
let addhero = ()=>{
    return {
        type: ADDHERO
    }
}
let removehero = ()=>{
    return {
        type: REMOVEHERO
    }
}
let sethero = (num)=>{
    return {
        type: SETHERO,
        payload: num
    }
}

//initial state is initial value of store object
let initialState = {
    numberOfHeroes: 0
}

//reducer is a function which has switch cases to call functions based on action type, only for state management
let reducer = (state=initialState, action) =>{
    switch(action.type){
        case ADDHERO: return {
            numberOfHeroes: state.numberOfHeroes+1
        }
        case REMOVEHERO: return {
            numberOfHeroes: state.numberOfHeroes-1
        }
        case SETHERO: return {
            numberOfHeroes: action.payload
        }
        default: return state;
    }
}

//store is an object that stores all shared states of your application
let store = createStore(reducer);
console.log("Initial state is ", store.getState())

//subscribe/unsubscribe to listen to changes of the store
let unsubscribe = store.subscribe(()=>{
    console.log("Subscribed: ", store.getState())
})


//dispatch is a method that can take action object
store.dispatch( addhero() )
store.dispatch( addhero() )
store.dispatch( removehero() )
store.dispatch( removehero() )
store.dispatch( sethero(5) )
unsubscribe();
store.dispatch( addhero() )

console.log(store.getState());
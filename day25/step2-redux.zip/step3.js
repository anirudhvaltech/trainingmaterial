let redux = require("redux");
let createStore = redux.legacy_createStore;
let combineReducers = redux.combineReducers;
let bindActionCreators = redux.bindActionCreators;

//action type
const ADDHERO="ADDHERO";
const REMOVEHERO="REMOVEHERO";
const SETHERO="SETHERO";

const ADDMOVIE="ADDMOVIE";
const REMOVEMOVIE="REMOVEMOVIE";
const SETMOVIE="SETMOVIE";

//action creator is function that returns an action object
let callAny = (action) =>{
    return {
        type: action.type
    }
}

let addhero = ()=>{
    return {
        type: ADDHERO
    }
}
let removehero = ()=>{
    return {
        type: REMOVEHERO
    }
}
let sethero = (num)=>{
    return {
        type: SETHERO,
        payload: num
    }
}

let addmovie = ()=>{
    return {
        type: ADDMOVIE
    }
}
let removemovie = ()=>{
    return {
        type: REMOVEMOVIE
    }
}
let setmovie = (num)=>{
    return {
        type: SETMOVIE,
        payload: num
    }
}

//initial state is initial value of store object
let initialHeroState = {
    numberOfHeroes: 0,

}
let initialMovieState = {

    numberOfMovies: 0,
}

//reducer is a function which has switch cases to call functions based on action type, only for state management
let heroReducer = (state=initialHeroState, action) =>{
    switch(action.type){
        case ADDHERO: return {
            ...state,numberOfHeroes: state.numberOfHeroes+1
        }
        case REMOVEHERO: return {
            ...state,numberOfHeroes: state.numberOfHeroes-1
        }
        case SETHERO: return {
            ...state,numberOfHeroes: action.payload
        }
        default: return state;
    }
}
let movieReducer = (state=initialMovieState, action) =>{
    switch(action.type){
        case ADDMOVIE: return {
            ...state,numberOfMovies: state.numberOfMovies+1
        }
        case REMOVEMOVIE: return {
            ...state,numberOfMovies: state.numberOfMovies-1
        }
        case SETMOVIE: return {
            ...state,numberOfMovies: action.payload
        }
        default: return state;
    }
}

let rootReducer = combineReducers({
    heroes: heroReducer,
    movies: movieReducer
})
//store is an object that stores all shared states of your application
let store = createStore(rootReducer);
console.log("Initial state is ", store.getState())

//subscribe/unsubscribe to listen to changes of the store
store.subscribe(()=>{
    console.log("Subscribed: ", store.getState())
})


// store.dispatch( addhero() )
// store.dispatch( addhero() )
// store.dispatch( removehero() )
// store.dispatch( removehero() )
// store.dispatch( sethero(5) )

// store.dispatch( addmovie() )
// store.dispatch( addmovie() )
// store.dispatch( removemovie() )
// store.dispatch( removemovie() )
// store.dispatch( setmovie(5) )

// unsubscribe();
// store.dispatch( addhero() )

//dispatch is a method that can take action object
store.dispatch( callAny( addhero() ))
let action = redux.bindActionCreators({addhero, removehero, sethero, addmovie, removemovie, setmovie}, store.dispatch)

action.addhero()
action.removehero()
action.sethero(5)
action.addmovie()
action.removemovie()
action.setmovie(5)

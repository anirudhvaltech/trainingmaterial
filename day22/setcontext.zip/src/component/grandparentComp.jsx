import { useState } from "react"
import FamilyContext from "../context/familtcontext";
import ParentComp from "./parentcomp";

let GrandParentComp =()=>{
    let [gift,updateGift]=useState(0)
    return <div style={{border:"2px solid grey",margin:"10px",padding:"10px"}}>
        <h1>Grand Parent Comp</h1>
        <button onClick={()=>updateGift(Math.round(Math.random()*10))}>Update</button>
        <FamilyContext.Provider value={gift}>
            <ParentComp/>
            {/* <CousinComp/> */}
        </FamilyContext.Provider>
    </div>
}
export default GrandParentComp;
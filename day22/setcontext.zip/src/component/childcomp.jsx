import FamilyContext from "../context/familtcontext";

let ChildComp =()=>{
    return <div style={{border:"2px solid grey",margin:"10px",padding:"10px"}}>
        <h1> Child Comp</h1>
        <FamilyContext.Consumer>{(val)=><h2>Gift Received :{val}</h2>}</FamilyContext.Consumer>
      
    </div>
}
export default ChildComp;
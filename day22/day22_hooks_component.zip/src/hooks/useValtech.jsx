let useValtech=()=>{
    return "Have a nice day!!";
}
export default useValtech;
import { useRef } from "react"
import { useReducer } from "react"

let UseReducerComponent=()=>{

    let fname=useRef()
    let lname=useRef()
    let cname=useRef()

    let reducerFun=(state,action)=>{
        switch(action.types){
            case "UPDATE_FIRSTNAME":return {...state, firstname:action.payload}
            case "UPDATE_LASTNAME":return {...state, lastname:action.payload}
            case "UPDATE_CITY":return {...state, city:action.payload}
        }
    }

    let [state,dispatch]=useReducer(reducerFun,{firstname:"",lastname:"",city:""})
    return <div>
        <h3>Use Reducer Hook Component</h3>
        <input type="text" ref={fname} />
        <button onClick={()=>dispatch({types:"UPDATE_FIRSTNAME",payload:fname.current.value})}>Set First Name</button>
        <h4>First Name : {state.firstname}</h4>
        <input type="text" ref={lname} />
        <button onClick={()=>dispatch({types:"UPDATE_LASTNAME",payload:lname.current.value})}>Set Last Name</button>
        <h4>Last Name : {state.lastname}</h4>
        <input type="text" ref={cname} />
        <button onClick={()=>dispatch({types:"UPDATE_CITY",payload:cname.current.value})}>Set City Name</button>
        <h4>City Name : {state.city}</h4>
    </div>
}
export {UseReducerComponent};
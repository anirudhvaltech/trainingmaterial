import { useContext } from "react";
import FamilyContext from "../contexts/family.context";

let ChildComponent=()=>{
    let grandgift=useContext(FamilyContext)
    return <div style={{border:"2px solid black",margin:"10px",padding:"5px"}}>
                <h3>Child Component</h3>
                {/* <FamilyContext.Consumer>{(val)=><h2>Gift Received : {val}</h2>}</FamilyContext.Consumer> */}
                <h3>{grandgift}</h3>
                <h3>{grandgift}</h3>
    </div>
}

export default ChildComponent;
import { useState } from "react"
import FamilyContext from "../contexts/family.context";
import CousinComponent from "./cousinComponent";
import ParentComp from "./parentComponent";

let GrandParentComp=()=>{
    let [gift,updateGift]=useState(0)
    return <div style={{border:"2px solid black",margin:"10px",padding:"5px"}}>
                <h3>Grand Parent Component</h3>
                <button onClick={()=>updateGift(Math.round(Math.random()*1000))}>Send Gift</button>
                <FamilyContext.Provider value={gift}>
                    <ParentComp/>
                    <CousinComponent/>
                </FamilyContext.Provider>
                
    </div>
}

export default GrandParentComp;
import FamilyContext from "../contexts/family.context"

let CousinComponent=()=>{
    return <div>
        <h3>Cousin Component</h3>
        <FamilyContext.Consumer>{(val)=><h2>Gift Received : {val}</h2>}</FamilyContext.Consumer>
    </div>
}

export default CousinComponent;
import ChildComponent from "./childComponent";

let ParentComp=()=>{
    return <div style={{border:"2px solid black",margin:"10px",padding:"5px"}}>
        <h3>Parent Component</h3>
        <ChildComponent/>
    </div>
}

export default ParentComp;
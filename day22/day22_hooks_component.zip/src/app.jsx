import { useState } from "react"
import GrandParentComp from "./components/grandParentComponent";
import { UseEffectComp } from "./components/useEffectComponent";
import { UseReducerComponent } from "./components/useReducerComponent";
import useValtech from "./hooks/useValtech";

 
export let App = ()=> {
   /*  
   let [power, setPower] = useState(0);
    let [version, setVersion] = useState(0);
    let [rating, setRating] = useState(0); 
    */
    let message=useValtech()
    let [state, setState] = useState({ power: 0, version : 0, rating : 0});
 
    return <div>
                <h1>Welcome to your life | Power is { state.power } | Version is : { state.version } | Rating : { state.rating }</h1>
                <input type="range" onChange={(evt)=> setState({...state, power: evt.target.value})} />
                <br />
                <input type="range" onChange={(evt)=> setState({...state, version : evt.target.value} )} />
                <br />
                <input type="range" onChange={(evt)=> setState({...state, rating: evt.target.value} )} />
                { state.power<50 ? <UseEffectComp state={state}/> : <h3>Component Removed</h3>}
                <UseReducerComponent/>
                <GrandParentComp/>
            </div>
}

export default App;